package pages;

import elementos.elementos;
import page.Metodos;

public class ComprarNoDebito {
	Metodos metodo = new Metodos();
	elementos elemento = new elementos();

	public void CompraNoDebito() {
		metodo.clicar(elemento.getDebitoVista());
		System.out.println(elemento.getDebitoVista());
		metodo.clicar(elemento.getFinalizarCompra());

	}

	public void validarCompraDebito() {
		metodo.validarTexto(elemento.getMensagemSucesso(), "Seu pedido foi realizado com sucesso", "");

	}

}
