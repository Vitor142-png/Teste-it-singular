package pages;

import elementos.elementos;
import page.Metodos;

public class ComprarCredito {
	Metodos metodo = new Metodos();
	elementos elemento = new elementos();

	public void Vista() {
		metodo.clicar(elemento.getCreditoVista());
		metodo.clicar(elemento.getFinalizarCompra());

	}

	public void Parcelado() {
		metodo.clicar(elemento.getCreditoParcelado());
		metodo.clicar(elemento.getFinalizarCompra());

	}

	public void ValidarCompraNoCredito() {
		metodo.validarTexto(elemento.getMensagemSucesso(), "Seu pedido foi realizado com sucesso", "");

	}

}
