package page;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;

public class Metodos extends Browser {
	public void escrever(By elemnto, String texto) {
		adriver().findElement(elemnto).sendKeys(texto);

	}

	public void clicar(By elemento) {
		adriver().findElement(elemento).click();

	}

	public void validarTexto(By elemento, String textoEsperado, String passo) {
		try {

			String textoCapturado = adriver().findElement(elemento).getText();
			assertEquals(textoEsperado, textoCapturado);
		} catch (Exception e) {
			System.err.println("-------- error ao validar texto -------" + passo + " " + e.getMessage());
		}

	}

	public void fecharNavegador() {

		adriver().quit();

	}

}
