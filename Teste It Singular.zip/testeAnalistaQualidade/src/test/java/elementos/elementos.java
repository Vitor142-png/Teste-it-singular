package elementos;

import org.openqa.selenium.By;

public class elementos {
	private By DebitoVista = By.id("debito");
	private By creditoVista = By.id("creditovista");
	private By creditoParcelado = By.id("creditoparcelado");
	private By finalizarCompra = By.className("Finalizar compra");
	private By numeroDoCartao = By.name("numero");
	private By nomeDoTitular = By.name("titula");
	private By dataDeVencimento = By.name("dataVencimento");
	private By codigoDeSeguranca = By.name("codSeguranca");
	private By mensagemSucesso = By.className("Seu pedido foi realizado com sucesso");

	public By getDebitoVista() {
		return DebitoVista;
	}

	public By getCreditoVista() {
		return creditoVista;
	}

	public By getCreditoParcelado() {
		return creditoParcelado;
	}

	public By getFinalizarCompra() {
		return finalizarCompra;
	}

	public By getNumeroDoCartao() {
		return numeroDoCartao;
	}

	public By getNomeDoTitular() {
		return nomeDoTitular;
	}

	public By getDataDeVencimento() {
		return dataDeVencimento;
	}

	public By getCodigoDeSeguranca() {
		return codigoDeSeguranca;
	}

	public By getMensagemSucesso() {
		return mensagemSucesso;
	}

}
