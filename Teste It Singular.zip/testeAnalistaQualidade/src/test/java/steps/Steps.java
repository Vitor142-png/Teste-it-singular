package steps;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import elementos.elementos;
import page.Metodos;
import pages.ComprarCredito;
import pages.ComprarNoDebito;

public class Steps {
	Metodos metodo = new Metodos();
	elementos elemento = new elementos();
	ComprarNoDebito Debito = new ComprarNoDebito();
	ComprarCredito credito = new ComprarCredito();

	

	@Given("^produto ja esta no carrinho e o endereco ja foi informado$")
	public void produto_ja_esta_no_carrinho_e_o_endereco_ja_foi_informado() throws Throwable {
		
	}

	@When("^escolho forma de pagamento Debito$")
	public void escolho_forma_de_pagamento_Debito() throws Throwable {
		Debito.CompraNoDebito();

	}

	@Then("^entao valido se a compra no Debito foi realizado com sucesso$")
	public void entao_valido_se_a_compra_no_Debito_foi_realizado_com_sucesso() throws Throwable {
		Debito.validarCompraDebito();
	}

	@When("^escolho forma de pagamento Credito a vista$")
	public void escolho_forma_de_pagamento_Credito_a_vista() throws Throwable {
		credito.Vista();

	}

	@Then("^entao valido se a compra no  Credito  foi realizado com sucesso$")
	public void entao_valido_se_a_compra_no_Credito_foi_realizado_com_sucesso() throws Throwable {
		credito.ValidarCompraNoCredito();
	}

	@When("^escolho forma de pagemtno Credito parcelado$")
	public void escolho_forma_de_pagemtno_Credito_parcelado() throws Throwable {
		credito.Parcelado();

	}

	@Then("^entao valido se a compra no Credito Parcelado foi realizado com sucesso$")
	public void entao_valido_se_a_compra_no_Credito_Parcelado_foi_realizado_com_sucesso() throws Throwable {
		credito.ValidarCompraNoCredito();

	}

}
